import re
import os
import shutil
from pathlib import Path
from tinytag import TinyTag, TinyTagException
from clilib.util.logging import Logging
from clilib.config.config_loader import JSONConfigurationFile


__version__ = "0.5.1"


default_config = {
    "output_format": "<artist>/<album>/<title>", 
    "default_tags": {
        "album": "Unknown",
        "albumartist": "Various Artists",
        "artist": "Various Artists",
        "bitrate": "0 kBits/s",
        "comment": "None",
        "composer": "Unknown",
        "disc": "0",
        "disc_total": "0",
        "duration": "0",
        "filesize": "0",
        "genre": "Unknown",
        "samplerate": "0",
        "title": "Unknown",
        "track": "0",
        "track_total": "0",
        "year": "Unknown"
    }
}

config_schema = {
    "output_format": str, 
    "default_tags": {
        "album": str,
        "albumartist": str,
        "artist": str,
        "bitrate": str,
        "comment": str,
        "composer": str,
        "disc": str,
        "disc_total": str,
        "duration": str,
        "filesize": str,
        "genre": str,
        "samplerate": str,
        "title": str,
        "track": str,
        "track_total": str,
        "year": str
    }
}


class Muzak:
    def __init__(self, scan_path: str, debug: bool = False) -> None:
        if scan_path is None:
            print("error: scan_path cannot be None")
            exit(1)
        self._scanned_paths = [scan_path]
        self.logger = Logging("Muzak", debug=debug).get_logger()
        self.config = self._load_config()
        self.files = self._find_files(scan_path)
        self.music = {}
        self.find_music()

    def _load_config(self):
        config_path = Path.home().joinpath(".config").joinpath("muzak").joinpath("config.json")
        config_path.parent.mkdir(parents=True, exist_ok=True)
        return JSONConfigurationFile(config_path, schema=config_schema, auto_create=default_config)

    def _filename_from_tag(self, tag: TinyTag):
        # TODO: Rework this to use the tag_as_dict and defaults instead of regex
        fmt = self.config["output_format"]
        defaults = self.config["default_tags"]
        tag_as_dict = tag.as_dict()
        for item, value in tag_as_dict.items():
            fmt_tag = "<%s>" % item
            if value is not None:
                fmt_val = re.sub(r'[^\w.\d-]', '', value)
            else:
                fmt_val = re.sub(r'[^\w.\d-]', '', defaults.get(item, "Unknown"))
            fmt.replace(fmt_tag, fmt_val)
        # parts = fmt.split("/")
        # path_parts = []
        # # Get attributes that we need from tag for dir
        # for part in parts:
        #     matches = re.findall('<(\w+)>', part)
        #     partname = ""
        #     # Loop through matches and ensure we have a value for 'part'
        #     for match in matches:
        #         if hasattr(tag, match):
        #             attr = getattr(tag, match)
        #             if attr is None:
        #                 attr = "Unknown"
        #             partname += attr
        #         else:
        #             partname += "Unknown"
        #     path_parts.append(partname)
        return fmt

    def _cleanup_dir(self, path: str):
        if not os.path.isdir(path):
            return
        files = os.listdir(path)
        for f in files:
            full_path = os.path.join(path, f)
            if os.path.isdir(full_path):
                self._cleanup_dir(full_path)
        
        files = os.listdir(path)
        if len(files) == 0:
            self.logger.info("Removing empty directory: [%s]" % path)
            os.rmdir(path)
        
    def _find_files(self, path: str):
        self.logger.info("Searching in path: %s" % path)
        files = []
        scan_path = Path(path)
        listing = os.listdir(path)
        for item in listing:
            item_path = scan_path.joinpath(item)
            if item_path.is_dir():
                self.logger.info("Found directory: %s" % item_path)
                l = self.find_files(str(item_path))
                for f in l:
                    self.logger.info("Found file %s in %s" % (f, item_path))
                files.extend(l)
            elif item_path.is_file():
                self.logger.info("Found file: %s" % item_path)
                files.append(str(item_path))
            else:
                self.logger.info("Item %s is not file or dir" % item)
        return files
    
    def scan_path(self, path: str):
        self.logger.info("Scanning path: [%s]" % path)
        self._scanned_paths.append(path)
        self.files.extend(self._find_files(path))
        self.find_music()

    def find_music(self):
        for item in self.files:
            try:
                tag = TinyTag.get(item)
                self.logger.info("Found track: Artist: [%s] Album: [%s] Track Number: [%s] Title: [%s]" % (tag.artist, tag.album, tag.track, tag.title))
                self.music[item] = tag
            except TinyTagException as e:
                self.logger.warn("Skipping file: %s, reason: %s (This is probably not an audio file)" % (item, str(e)))

    def organize(self, destination: str, move: bool = True, cleanup_empty: bool = False, dry_run: bool = False):
        """
        Organize detected music files in the given destination folder. Optionally cleanup
        empty directories afterwards.
        :param destination: Destination directory for organized music.
        :param move: Move files to destination instead of copying. Default is true.
        :param cleanup_empty: Cleanup empty directories after music has been organized. This is false by default.
        """
        
        # Create destination if not exists.
        destination = Path(destination)
        if not destination.exists():
            destination.mkdir(parents=True)

        for item, tag in self.music.items():
            # Gracefully fail this iteration if file has been moved/deleted/something else
            item_path = Path(item)
            if not item_path.exists():
                self.logger.warn("File [%s] no longer exists. Skipping..." % item)
            
            new_filename = destination.joinpath("%s%s" % (self._filename_from_tag(tag), item_path.suffix))
            parent_dir = Path(new_filename).parent
            if not dry_run:
                if not parent_dir.exists():
                    parent_dir.mkdir(parents=True)
            if move:
                self.logger.info("Moving [%s] => [%s]" % (item, new_filename))
                if not dry_run:
                    os.rename(item, str(new_filename))
            else:
                self.logger.info("Copying [%s] => [%s]" % (item, new_filename))
                if not dry_run:
                    shutil.copy(item, str(new_filename))
        
        if cleanup_empty:
            for path in self._scanned_paths:
                self._cleanup_dir(path)
