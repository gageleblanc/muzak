from muzak import Muzak
from clilib.builders.app import EasyCLI


class MuzakCLI:
    """
    Scan a directory to locate and organize audio files based on tags.
    """
    def __init__(self, ebug: bool = False):
        """
        :param debug: Add additional debugging output
        """
        self.debug = ebug

    def organize(self, paths: str, destination: str = None, move: bool = False, cleanup_empty: bool = False, dry_run: bool = False):
        """
        Scan given path for music files, and then organize them in the given destination directory.
        :param paths: Path to scan for music
        :param destination: Destination path for organized music
        :param move: Move files to destination instead of copying
        :param cleanup_empty: Cleanup empty directories after organize operation. This is most useful when moving files.
        :param dry_run: Simulate organize operation without actually copying or moving files.
        """
        muzak = Muzak(paths, debug=self.debug)
        muzak.organize(destination, move, cleanup_empty, dry_run)


def cli():
    EasyCLI(MuzakCLI, enable_logging=True, debug=True)
